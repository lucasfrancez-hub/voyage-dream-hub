/* Via Air — bridge content script
 *
 * Roda nas páginas do admin da Via Air (Lovable preview/prod + domínio
 * custom). Escuta window.postMessage vindo do próprio admin com o token
 * gerado e persiste em chrome.storage.local sob a chave da companhia,
 * pra que o content.js leia quando a página da cia abrir.
 */
(function () {
  const VERSION = "1.8.0";
  const API_BASE = "https://pedidos.viaair.tur.br";

  function announce() {
    window.postMessage({ __viaair: "ready", version: VERSION }, "*");
  }

  window.addEventListener("message", (ev) => {
    if (ev.source !== window) return;
    const d = ev.data;
    if (!d) return;

    // Ping do admin — respondemos com nossa versão.
    if (d.__viaair === "ping") { announce(); return; }

    // Importador de catálogo (Infotravel)
    if (d.__viaair === "catalog-start") {
      if (!d.token) return;
      try {
        chrome.storage.local.set(
          {
            "viaair::catalog": {
              token: d.token,
              apiBase: d.apiBase || API_BASE,
              config: d.config || {},
              savedAt: Date.now(),
            },
            "viaair::catalog::control": "running",
          },
          () => window.postMessage({ __viaair: "catalog-start-ack", version: VERSION }, "*"),
        );
      } catch (e) {
        window.postMessage({ __viaair: "catalog-err", error: String((e && e.message) || e) }, "*");
      }
      return;
    }
    if (d.__viaair === "catalog-control") {
      try { chrome.storage.local.set({ "viaair::catalog::control": d.status }); } catch (e) { /* noop */ }
      return;
    }



    if (d.__viaair !== "set-token") return;
    const { token, airline } = d;
    if (!token || !airline) return;
    const ALL = ["latam", "gol", "azul", "skyteam", "frt", "visualturismo", "infotera"];
    const targets = airline === "any"
      ? ALL
      : (ALL.includes(airline) ? [airline] : []);
    if (targets.length === 0) return;
    try {
      const payload = {};
      for (const a of targets) {
        payload["viaair::" + a] = { token, apiBase: API_BASE, airline: a, savedAt: Date.now() };
      }
      chrome.storage.local.set(payload, () => {
        const err = chrome.runtime && chrome.runtime.lastError;
        if (err) {
          window.postMessage({ __viaair: "set-token-err", error: String(err.message || err) }, "*");
        } else {
          window.postMessage({ __viaair: "set-token-ack", airline, version: VERSION }, "*");
        }
      });
    } catch (e) {
      window.postMessage({ __viaair: "set-token-err", error: String((e && e.message) || e) }, "*");
    }
  });

  // Anúncio inicial + reanuncia depois pra pegar listeners que subiram depois.
  announce();
  setTimeout(announce, 500);
  setTimeout(announce, 2000);
})();
